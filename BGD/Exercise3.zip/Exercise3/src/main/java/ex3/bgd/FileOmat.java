package ex3.bgd;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FileOmat {

	public static void main(String[] args) {
		SpringApplication.run(FileOmat.class, args);
	}

}
